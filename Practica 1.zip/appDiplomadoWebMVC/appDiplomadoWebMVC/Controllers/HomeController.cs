﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace appDiplomadoWebMVC.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public string Index()
        {
            return "<html><body>" +
                    "<h1>Universidad Autonoma de Santo Domingo (UASD)</h1>"+
                    "<p>Diplomado Desarrollo Web C#, MVC</p>"+
                    "</body></html>";
                
        }

        public string DiplomadoWeb()
        {
            return "<html><body>" +
                    "<h1>Estudiantes:</h1>" +
                    "<p>Eduard Antonio Torres<br>" +
                    "Ana Iris Feliz Montilla<br>" +
                    "Maria alejandra De la Rosa </p>" +
                    "</body></html>";
        }
    }
}